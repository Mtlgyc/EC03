package Sistema;

public class Main {
    // Método principal que é o ponto de entrada do programa Java
    public static void main(String[] args) {
        // Cria uma nova instância da classe Terminal e chama o método ini
        new Terminal().ini();
    }
}